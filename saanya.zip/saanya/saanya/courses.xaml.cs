﻿using saanya.u1610850_P9MacDataSetTableAdapters;
using sanya;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace saanya
{
    /// <summary>
    /// Логика взаимодействия для courses.xaml
    /// </summary>
    public partial class courses : Page
    {
        coursesTableAdapter courses_ = new coursesTableAdapter();
        public courses()
        {
            InitializeComponent();
            coursGrid.ItemsSource = courses_.GetData();
        }

        private void CitiesGrid_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            try
            {
                idcourse.Text = (coursGrid.SelectedItem as DataRowView).Row[1].ToString();
                namecourse.Text = (coursGrid.SelectedItem as DataRowView).Row[2].ToString();
                decrcourse.Text = (coursGrid.SelectedItem as DataRowView).Row[3].ToString();
                hoursecourse.Text = (coursGrid.SelectedItem as DataRowView).Row[4].ToString();
            }
            catch
            {

            }
        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            coursFrame.Content = new Admin();
        }

        private void InsertBtn_Click(object sender, RoutedEventArgs e)
        {
            if ((string.IsNullOrWhiteSpace(idcourse.Text)) && (string.IsNullOrWhiteSpace(namecourse.Text)) && (string.IsNullOrWhiteSpace(decrcourse.Text)) &&
                (string.IsNullOrWhiteSpace(hoursecourse.Text)))
            {

            }
            else if (namecourse.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && namecourse.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && hoursecourse.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0")

            {

            }

            else if (idcourse.Text.FirstOrDefault(element => char.IsLetter(element)).ToString() != "\0")
            {
                MessageBox.Show("аЙди Ввел пРавИльнО ЧоРТ");
            }
            else if (hoursecourse.Text.FirstOrDefault(element => char.IsLetter(element)).ToString() != "\0")
            {
                MessageBox.Show("ЧасЫ вВЕДЕНН НЕ вВеННА");
            }

            else
            {
                try
                {
                    courses_.InsertQuery(Convert.ToInt32(idcourse.Text), namecourse.Text, decrcourse.Text, Convert.ToInt32 (hoursecourse.Text));
                    coursGrid.ItemsSource = courses_.GetData();
                }
                catch
                {

                }
                finally
                {
                    idcourse.Text = null;
                    namecourse.Text = null;
                    decrcourse.Text = null;
                    hoursecourse.Text = null;
                    coursGrid.ItemsSource = courses_.GetData();
                }
            }
        }

        private void DelCityBtn_Click(object sender, RoutedEventArgs e)
        {
            if (coursGrid.SelectedItems != null)
            {
                try
                {
                    courses_.DeleteQuery((int)(coursGrid.SelectedItem as DataRowView).Row[0]);
                    coursGrid.ItemsSource = courses_.GetData();
                }
                catch
                {

                }
            }
        }

        private void UpdateBtn_Click(object sender, RoutedEventArgs e)
        {
            if ((string.IsNullOrWhiteSpace(idcourse.Text)) && (string.IsNullOrWhiteSpace(namecourse.Text)) && (string.IsNullOrWhiteSpace(decrcourse.Text)) &&
                (string.IsNullOrWhiteSpace(hoursecourse.Text)))
            {

            }
            else if (idcourse.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && namecourse.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && decrcourse.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0")

            {

            }

            else if (idcourse.Text.FirstOrDefault(element => char.IsLetter(element)).ToString() != "\0")
            {

            }

            else
            {
                try
                {
                    courses_.UpdateQuery(Convert.ToInt32(idcourse.Text), namecourse.Text, decrcourse.Text, Convert.ToInt32(hoursecourse.Text), (int)(coursGrid.SelectedItem as DataRowView).Row[0]);
                    coursGrid.ItemsSource = courses_.GetData();
                }
                catch
                {

                }
                finally
                {
                    idcourse.Text = null;
                    namecourse.Text = null;
                    decrcourse.Text = null;
                    hoursecourse.Text = null;
                    coursGrid.ItemsSource = courses_.GetData();
                }
            }
        }

        private void coursFrame_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {

        }
    }
}
