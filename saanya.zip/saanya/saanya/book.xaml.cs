﻿using saanya.u1610850_P9MacDataSetTableAdapters;
using sanya;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace saanya
{
    /// <summary>
    /// Логика взаимодействия для book.xaml
    /// </summary>
    public partial class book : Page
    {
        library_booksTableAdapter books_ = new library_booksTableAdapter();
        public book()
        {
            InitializeComponent();
            ProdsGrid.ItemsSource = books_.GetData();
        }

        private void ProdsGrid_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            try
            {
                DiscInBox.Text = (ProdsGrid.SelectedItem as DataRowView).Row[1].ToString();
                SellInBox.Text = (ProdsGrid.SelectedItem as DataRowView).Row[2].ToString();
                BOOK1.Text = (ProdsGrid.SelectedItem as DataRowView).Row[3].ToString();
                BOOK2.Text = (ProdsGrid.SelectedItem as DataRowView).Row[4].ToString();
                BOOK3.Text = (ProdsGrid.SelectedItem as DataRowView).Row[5].ToString();
            }
            catch
            {

            }
        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            booksFrame.Content = new Admin();
        }

        private void InsertBtn_Click(object sender, RoutedEventArgs e)
        {
            if ((string.IsNullOrWhiteSpace(DiscInBox.Text)) && (string.IsNullOrWhiteSpace(SellInBox.Text)) && (string.IsNullOrWhiteSpace(BOOK1.Text)) &&
                (string.IsNullOrWhiteSpace(BOOK2.Text)) && (string.IsNullOrWhiteSpace(BOOK3.Text)))
            {

            }
            else if (SellInBox.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && BOOK1.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && BOOK2.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0")

            {

            }

            else if (DiscInBox.Text.FirstOrDefault(element => char.IsLetter(element)).ToString() != "\0")
            {

            }

            else
            {
                try
                {
                    books_.InsertQuery(Convert.ToInt32(DiscInBox.Text), SellInBox.Text, Convert.ToInt32 (BOOK1.Text), BOOK2.Text, Convert.ToInt32 (BOOK3.Text));
                    ProdsGrid.ItemsSource = books_.GetData();
                }
                catch
                {

                }
                finally
                {
                    DiscInBox.Text = null;
                    SellInBox.Text = null;
                    BOOK1.Text = null;
                    BOOK2.Text = null;
                    BOOK3.Text = null;
                    ProdsGrid.ItemsSource = books_.GetData();
                }
            }
        }

        private void DelBtn_Click(object sender, RoutedEventArgs e)
        {
            if (ProdsGrid.SelectedItems != null)
            {
                try
                {
                    books_.DeleteQuery((int)(ProdsGrid.SelectedItem as DataRowView).Row[0]);
                    ProdsGrid.ItemsSource = books_.GetData();
                }
                catch
                {

                }
            }
        }

        private void UpdateBtn_Click(object sender, RoutedEventArgs e)
        {
            if ((string.IsNullOrWhiteSpace(DiscInBox.Text)) && (string.IsNullOrWhiteSpace(SellInBox.Text)) && (string.IsNullOrWhiteSpace(BOOK1.Text)) &&
                (string.IsNullOrWhiteSpace(BOOK2.Text)) && (string.IsNullOrWhiteSpace(BOOK3.Text)))
            {

            }
            else if (DiscInBox.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && SellInBox.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && BOOK1.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0")

            {

            }

            else if (DiscInBox.Text.FirstOrDefault(element => char.IsLetter(element)).ToString() != "\0")
            {

            }

            else
            {
                try
                {
                    books_.UpdateQuery(Convert.ToInt32(DiscInBox.Text), SellInBox.Text, Convert.ToInt32(BOOK1.Text), BOOK2.Text, Convert.ToInt32(BOOK3.Text), (int)(ProdsGrid.SelectedItem as DataRowView).Row[0]);

                }
                catch
                {

                }
                finally
                {
                    DiscInBox.Text = null;
                    SellInBox.Text = null;
                    BOOK1.Text = null;
                    BOOK2.Text = null;
                    BOOK3.Text = null;
                    ProdsGrid.ItemsSource = books_.GetData();
                }
            }
        }
    }
}
