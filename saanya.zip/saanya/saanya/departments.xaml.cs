﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using saanya.u1610850_P9MacDataSetTableAdapters;
using sanya;

namespace saanya
{
    /// <summary>
    /// Логика взаимодействия для departments.xaml
    /// </summary>
    public partial class departments : Page
    {
        departmentsTableAdapter dep_ = new departmentsTableAdapter();
        professorsTableAdapter professors_ = new professorsTableAdapter();
        studentsTableAdapter students_ = new studentsTableAdapter();
        public departments()
        {
            InitializeComponent();
            depGrid.ItemsSource = dep_.GetData();
            profBox.ItemsSource = professors_.GetData();
            profBox.DisplayMemberPath = "professor_id";
            profBox.SelectedValuePath = "first_name";

            studBox.ItemsSource = students_.GetData();
            studBox.DisplayMemberPath = "student_id";
            studBox.SelectedValuePath = "first_name";
        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            depFrame.Content = new Admin();
        }

        private void InsertBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void DelCityBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void UpdateBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void depGrid_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            try
            {
                iddepar.Text = (depGrid.SelectedItem as DataRowView).Row[1].ToString();
                namedepart.Text = (depGrid.SelectedItem as DataRowView).Row[2].ToString();
                decrdescr.Text = (depGrid.SelectedItem as DataRowView).Row[3].ToString();
            }
            catch
            {

            }
        }

        private void depFrame_Navigated(object sender, NavigationEventArgs e)
        {

        }

        private void depFrame_Navigated_1(object sender, NavigationEventArgs e)
        {

        }
    }
}
