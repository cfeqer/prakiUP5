﻿using saanya.u1610850_P9MacDataSetTableAdapters;
using sanya;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace saanya
{
    /// <summary>
    /// Логика взаимодействия для proffesor.xaml
    /// </summary>
    public partial class proffesor : Page
    {
        professorsTableAdapter professors_ = new professorsTableAdapter();
        public proffesor()
        {
            InitializeComponent();
            CitiesGrid.ItemsSource = professors_.GetData();
        }

        private void CitiesGrid_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            try
            {
                profesid.Text = (CitiesGrid.SelectedItem as DataRowView).Row[0].ToString();
                fnameprofs.Text = (CitiesGrid.SelectedItem as DataRowView).Row[1].ToString();
                secnameprofs.Text = (CitiesGrid.SelectedItem as DataRowView).Row[2].ToString();
                adressprof.Text = (CitiesGrid.SelectedItem as DataRowView).Row[3].ToString();
                phoneprofessor.Text = (CitiesGrid.SelectedItem as DataRowView).Row[4].ToString();
            }
            catch 
            { 
            
            }
        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            profFrame.Content = new Admin();
        }

        private void InsertBtn_Click(object sender, RoutedEventArgs e)
        {
            if ((string.IsNullOrWhiteSpace(profesid.Text)) && (string.IsNullOrWhiteSpace(fnameprofs.Text)) && (string.IsNullOrWhiteSpace(secnameprofs.Text)) &&
                (string.IsNullOrWhiteSpace(adressprof.Text)) && (string.IsNullOrWhiteSpace(phoneprofessor.Text)))
            {

            }
            else if (fnameprofs.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && secnameprofs.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && adressprof.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0")

            {

            }

            else if (profesid.Text.FirstOrDefault(element => char.IsLetter(element)).ToString() != "\0")
            {
                MessageBox.Show("аЙди Ввел пРавИльнО ЧоРТ");
            }
            else if (phoneprofessor.Text.FirstOrDefault(element => char.IsLetter(element)).ToString() != "\0")
            {
                MessageBox.Show("нОМеР вВЕДЕНН НЕ вВеННА");
            }

            else
            {
                try
                {
                    professors_.InsertQuery(Convert.ToInt32(profesid.Text), fnameprofs.Text, secnameprofs.Text, adressprof.Text, phoneprofessor.Text);
                }
                catch
                {

                }
                finally
                {
                    profesid.Text = null;
                    fnameprofs.Text = null;
                    secnameprofs.Text = null;
                    adressprof.Text = null;
                    phoneprofessor.Text = null;
                    CitiesGrid.ItemsSource = professors_.GetData();
                }
            }
        }

        private void DelCityBtn_Click(object sender, RoutedEventArgs e)
        {
            if (CitiesGrid.SelectedItems != null)
            {
                try
                {
                    professors_.DeleteQuery((int)(CitiesGrid.SelectedItem as DataRowView).Row[0]);
                    CitiesGrid.ItemsSource = professors_.GetData();
                }
                catch
                {

                }
            }
        }

        private void UpdateBtn_Click(object sender, RoutedEventArgs e)
        {
            if ((string.IsNullOrWhiteSpace(profesid.Text)) && (string.IsNullOrWhiteSpace(fnameprofs.Text)) && (string.IsNullOrWhiteSpace(secnameprofs.Text)) &&
                (string.IsNullOrWhiteSpace(adressprof.Text)) && (string.IsNullOrWhiteSpace(phoneprofessor.Text)))
            {

            }
            else if (fnameprofs.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && secnameprofs.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && adressprof.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0")

            {

            }

            else if (profesid.Text.FirstOrDefault(element => char.IsLetter(element)).ToString() != "\0")
            {

            }

            else
            {
                try
                {
                    professors_.UpdateQuery(Convert.ToInt32(profesid.Text), fnameprofs.Text, secnameprofs.Text, adressprof.Text, phoneprofessor.Text, (int)(CitiesGrid.SelectedItem as DataRowView).Row[0]);
                }
                catch
                {

                }
                finally
                {
                    profesid.Text = null;
                    fnameprofs.Text = null;
                    secnameprofs.Text = null;
                    adressprof.Text = null;
                    phoneprofessor.Text = null;
                    CitiesGrid.ItemsSource = professors_.GetData();
                }
            }
        }

        private void profFrame_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {

        }
    }
}
