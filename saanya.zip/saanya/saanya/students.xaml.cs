﻿using saanya.u1610850_P9MacDataSetTableAdapters;
using sanya;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace saanya
{
    /// <summary>
    /// Логика взаимодействия для students.xaml
    /// </summary>
    public partial class students : Page
    {
        studentsTableAdapter students_ = new studentsTableAdapter();
        public students()
        {
            InitializeComponent();
            studGrid.ItemsSource = students_.GetData();
        }

        private void CitiesGrid_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            try
            {
                idprof.Text = (studGrid.SelectedItem as DataRowView).Row[0].ToString();
                fprof.Text = (studGrid.SelectedItem as DataRowView).Row[1].ToString();
                sprof.Text = (studGrid.SelectedItem as DataRowView).Row[2].ToString();
                adprof.Text = (studGrid.SelectedItem as DataRowView).Row[3].ToString();
                dirstprof.Text = (studGrid.SelectedItem as DataRowView).Row[4].ToString();
            }
            catch
            {
                
            }
        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            studFrame.Content = new Admin();
        }

        private void InsertBtn_Click(object sender, RoutedEventArgs e)
        {
            if ((string.IsNullOrWhiteSpace(idprof.Text)) && (string.IsNullOrWhiteSpace(fprof.Text)) && (string.IsNullOrWhiteSpace(sprof.Text)) &&
                (string.IsNullOrWhiteSpace(adprof.Text)) && (string.IsNullOrWhiteSpace(dirstprof.Text)))
            {

            }
            else if (fprof.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && sprof.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && adprof.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && dirstprof.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0")

            {

            }

            else if (idprof.Text.FirstOrDefault(element => char.IsLetter(element)).ToString() != "\0")
            {

            }

            else
            {
                try
                {
                    students_.InsertQuery(Convert.ToInt32 (idprof.Text), fprof.Text, sprof.Text, adprof.Text, dirstprof.Text);
                    studGrid.ItemsSource = students_.GetData();
                }
                catch
                {

                }
                finally
                {
                    idprof.Text = null;
                    fprof.Text = null;
                    sprof.Text = null;
                    adprof.Text = null;
                    dirstprof.Text = null;
                    studGrid.ItemsSource = students_.GetData();
                }
            }

        }

        private void DelCityBtn_Click(object sender, RoutedEventArgs e)
        {
            if (studGrid.SelectedItems != null)
            {
                try
                {
                    students_.DeleteQuery((int)(studGrid.SelectedItem as DataRowView).Row[0]);
                    studGrid.ItemsSource = students_.GetData();
                }
                catch
                {

                }
            }
        }

        private void UpdateBtn_Click(object sender, RoutedEventArgs e)
        {
            if ((string.IsNullOrWhiteSpace(idprof.Text)) && (string.IsNullOrWhiteSpace(fprof.Text)) && (string.IsNullOrWhiteSpace(sprof.Text)) &&
                (string.IsNullOrWhiteSpace(adprof.Text)) && (string.IsNullOrWhiteSpace(dirstprof.Text)))
            {

            }
            else if (fprof.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && sprof.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0" && adprof.Text.FirstOrDefault(element => char.IsDigit(element)).ToString() != "\0")

            {

            }

            else if (idprof.Text.FirstOrDefault(element => char.IsLetter(element)).ToString() != "\0")
            {

            }

            else
            {
                try
                {
                    students_.UpdateQuery(Convert.ToInt32(idprof.Text), fprof.Text, sprof.Text, adprof.Text, dirstprof.Text, (int)(studGrid.SelectedItem as DataRowView).Row[0]);
                    studGrid.ItemsSource = students_.GetData();
                }
                catch
                {

                }
                finally
                {
                    idprof.Text = null;
                    fprof.Text = null;
                    sprof.Text = null;
                    adprof.Text = null;
                    dirstprof.Text = null;
                    studGrid.ItemsSource = students_.GetData();
                }
            }
        }

        private void studFrame_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {

        }
    }
}
