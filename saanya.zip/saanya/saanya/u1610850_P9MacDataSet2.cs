﻿namespace saanya
{


    partial class u1610850_P9MacDataSet
    {
    }
}

namespace saanya.u1610850_P9MacDataSetTableAdapters
{
    partial class professorsTableAdapter
    {
    }

    partial class studentsTableAdapter
    {
    }

    public partial class library_booksTableAdapter {
    }
}
