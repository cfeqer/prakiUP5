﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using saanya.u1610850_P9MacDataSetTableAdapters;

namespace sanya
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        studentsTableAdapter studentsTableAdapter = new studentsTableAdapter();
        public MainWindow()
        {
            InitializeComponent();
            RoleBox.Items.Add("student");
            RoleBox.Items.Add("professor");
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            if (username.Text != "")
            {
                var usersData = studentsTableAdapter.GetData();
                int ind = 0;

                for (int i = 0; i < usersData.Count; i++)
                {

                    if ((usersData[i][1].ToString() == username.Text))
                    {
                        ind = Convert.ToInt32(usersData[i][0]);
                        MessageBox.Show(ind.ToString());
                        break;
                    }
                }
                

                if (ind != 0)
                {
                    username.Text = null;
                    switch (RoleBox.SelectedIndex)
                    {
                        case 0:
                            AllFrame.Content = new Admin();
                            break;
                    }

                }
                else
                {
                    MessageBox.Show("Неверный логин или пароль");
                }
            }
        }
    }
}
