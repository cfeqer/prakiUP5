﻿using saanya;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace sanya
{
    /// <summary>
    /// Логика взаимодействия для Admin.xaml
    /// </summary>
    public partial class Admin : Page
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void BooksBtn_Click(object sender, RoutedEventArgs e)
        {
            AdminFrame.Content = new book();
        }

        private void CoursesBtn_Click(object sender, RoutedEventArgs e)
        {
            AdminFrame.Content = new courses(); 
        }

        private void ProffesorsBtn_Click(object sender, RoutedEventArgs e)
        {
            AdminFrame.Content = new proffesor();
        }

        private void StudentsBtn_Click(object sender, RoutedEventArgs e)
        {
            AdminFrame.Content = new students();
        }

        private void AdminFrame_Navigated(object sender, NavigationEventArgs e)
        {

        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            (Application.Current.MainWindow as MainWindow).AllFrame.Content = null;
        }

        private void devBtn_Click(object sender, RoutedEventArgs e)
        {
            AdminFrame.Content = new departments();
        }
    }
}
